#include "Scene.h"

Scene::T_Scene()
{
}

Scene::~T_Scene()
{
}

Integer Scene::getSceneX()
{
}

Integer Scene::getSceneY()
{
}

Integer Scene::getlastSceneX()
{
}

Integer Scene::getlastSceneY()
{
}

Map Scene::getBarrier()
{
}

Map Scene::getMask()
{
}

Integer Scene::GetTotalLayers()
{
}

SCENE_LAYERS Scene::getSceneLayers()
{
}

Scene::InitScene()
{
}

Scene::SetScenePos()
{
}

Scene::MoveScene()
{
}

Scene::ScrollScene()
{
}

Scene::Append()
{
}

Scene::Insert()
{
}

Scene::Remove()
{
}

Scene::RemoveAll()
{
}

Scene::SortLayers()
{
}

POINT Scene::getRandomFreeCell()
{
}

Scene::GetTxtMapValue()
{
}

Scene::GetTxtMapValue()
{
}

Scene::parseCsvData()
{
}

Boolean Scene::LoadTxtMap()
{
}

Scene::Draw()
{
}

Scene::Scene()
{
}


Boolean Scene::SortByZorder()
{
}

