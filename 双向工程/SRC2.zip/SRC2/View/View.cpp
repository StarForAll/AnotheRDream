#include "View.h"

View::View()
{
}

View::~View()
{
}

Scene View::GetMainScene()
{
}

View::SetMainScene()
{
}

Scene View::GetChooseMusic()
{
}

View::SetChooseMusic()
{
}

Scene View::GetPlayScene()
{
}

View::SetPlayScene()
{
}

View::ShowSigninView()
{
}

View::SureSignin()
{
}

View::ShowGameResult()
{
}

View::ShowReultMessage()
{
}

View::ReadConfigurationFile()
{
}

View::RequestShow()
{
}

