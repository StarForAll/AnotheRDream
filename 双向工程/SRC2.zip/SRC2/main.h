#ifndef MAIN_H_HEADER_INCLUDED_A21BC8C0
#define MAIN_H_HEADER_INCLUDED_A21BC8C0

class main
{
  public:
    main();

};



#endif /* MAIN_H_HEADER_INCLUDED_A21BC8C0 */
