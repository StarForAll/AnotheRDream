#include "AudioWave.h"

AudioWave::AudioWave()
{
}

AudioWave::~AudioWave()
{
}

Boolean AudioWave::Open()
{
}

Boolean AudioWave::StartRead()
{
}

Boolean AudioWave::Read()
{
}

Boolean AudioWave::Close()
{
}

WAVEFORMATEX *AudioWave::GetFormat()
{
}

DWORD AudioWave::CkSize()
{
}

