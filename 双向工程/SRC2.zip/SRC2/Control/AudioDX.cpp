#include "AudioDX.h"

AudioDX::~AudioDX()
{
}

AudioDX::AudioDX()
{
}

Boolean AudioDX::CreateDS()
{
}

LPDIRECTSOUND AudioDX::operator ->()
{
}

AudioDX::ReleaseAll()
{
}

HRESULT AudioDX::RestoreAll()
{
}

AudioDX::PlayMusic()
{
}

