#include "LAYERINFO.h"

LAYERINFO::LAYERINFO()
{
}


