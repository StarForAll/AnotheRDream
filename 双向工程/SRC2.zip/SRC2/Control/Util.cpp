#include "Util.h"

HWND Util::GetHWnd()
{
}

HINSTANCE Util::GetHInst()
{
}

wchar_t *Util::int_to_wstring()
{
}

Util::GetRandomNum()
{
}

Util::GetBevelSpeed()
{
}

Util::RequestReadConfigurationFile()
{
}

Util::WriteToConfiguration()
{
}

Util::Util()
{
}


