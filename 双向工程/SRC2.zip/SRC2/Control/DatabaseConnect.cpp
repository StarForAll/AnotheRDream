#include "DatabaseConnect.h"

DatabaseConnect::Database()
{
}

DatabaseConnect::~Database()
{
}

DatabaseConnect::Connect()
{
}

DatabaseConnect::Close()
{
}

String DatabaseConnect::Select()
{
}

Boolean DatabaseConnect::Insert()
{
}

Boolean DatabaseConnect::Delete()
{
}

Boolean DatabaseConnect::Alter()
{
}

DatabaseConnect::DatabaseConnect()
{
}


