#include "Graph.h"

Graph::Graph()
{
}

Graph::~Graph()
{
}

HBITMAP Graph::GetBmpHandle()
{
}

Integer Graph::GetImageWidth()
{
}

Integer Graph::GetImageHeight()
{
}

Boolean Graph::LoadImageFile()
{
}

Graph::PaintImage()
{
}

Graph::Destroy()
{
}

HBITMAP Graph::CreateBlankBitmap()
{
}

Bitmap* Graph::HBITMAP_To_Bitmap()
{
}

Graph::PaintRegion()
{
}

Graph::PaintFrame()
{
}

Graph::PaintBlank()
{
}

Graph::PaintText()
{
}

