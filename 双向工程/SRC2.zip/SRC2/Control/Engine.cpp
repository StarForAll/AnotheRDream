#include "Engine.h"

Engine::Engine()
{
}

Engine::~Engine()
{
}

Integer Engine::GetInterval()
{
}

Engine::SetFrame()
{
}

Boolean Engine::GetSleep()
{
}

Engine::SetSleep()
{
}

Engine::SetFullScreen()
{
}

Boolean Engine::CheckKey()
{
}

Engine::SubKeyAction()
{
}

Engine::SetBackColor()
{
}

static LRESULT CALLBACK Engine::WndProc()
{
}

Boolean Engine::GameWinInit()
{
}

LRESULT Engine::GameEvent()
{
}

Engine::StartEngine()
{
}

virtual void Engine::GameInit()
{
}

virtual void Engine::GameLogic()
{
}

virtual void Engine::GameEnd()
{
}

virtual void Engine::GamePaint()
{
}

virtual void Engine::GameKeyAction()
{
}

virtual void Engine::GameMouseAction()
{
}

Engine::Signin()
{
}

