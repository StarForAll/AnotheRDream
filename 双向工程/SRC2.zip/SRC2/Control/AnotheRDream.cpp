#include "AnotheRDream.h"

AnotheRDream::AnotheRDream()
{
}

AnotheRDream::~AnotheRDream()
{
}

AnotheRDream::PlayerInputInfo()
{
}

AnotheRDream::CheckPlayerInfo()
{
}

AnotheRDream::CheckSuccess()
{
}

AnotheRDream::GetPlayerNotesPos()
{
}

AnotheRDream::ShowResult()
{
}

AnotheRDream::JudgeEnd()
{
}

AnotheRDream::GetEndState()
{
}

AnotheRDream::RequestUpdateInfo()
{
}

AnotheRDream::ShowRequestUpdateInfo()
{
}

AnotheRDream::CheckUpdateInfo()
{
}

AnotheRDream::RequestQuery()
{
}

AnotheRDream::ShowRequest()
{
}

AnotheRDream::CheckRequestQuery()
{
}

AnotheRDream::ChooseMusic()
{
}

AnotheRDream::Startup()
{
}

