#include "Display.h"

Display::SaveMode()
{
}

Display::ResetMode()
{
}

Boolean Display::ChangeMode()
{
}

Display::Display()
{
}


