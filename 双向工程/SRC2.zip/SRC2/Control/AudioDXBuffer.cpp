#include "AudioDXBuffer.h"

AudioDXBuffer::~AudioDXBuffer()
{
}

AudioDXBuffer::AudioDXBuffer()
{
}

Boolean AudioDXBuffer::CreateBuffer()
{
}

Boolean AudioDXBuffer::CreateMainBuffer()
{
}

Boolean AudioDXBuffer::LoadWave()
{
}

HRESULT AudioDXBuffer::Release()
{
}

HRESULT AudioDXBuffer::Restore()
{
}

AudioDXBuffer::Terminate()
{
}

Boolean AudioDXBuffer::Play()
{
}

Boolean AudioDXBuffer::Stop()
{
}

Boolean AudioDXBuffer::IsAlive()
{
}

LPDIRECTSOUNDBUFFER AudioDXBuffer::operator ->()
{
}

