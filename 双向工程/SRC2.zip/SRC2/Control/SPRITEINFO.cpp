#include "SPRITEINFO.h"

SPRITEINFO::SPRITEINFO()
{
}


