#include "PlayerInfo.h"

PlayerInfo::setID()
{
}

PlayerInfo::setName()
{
}

PlayerInfo::setSign()
{
}

PlayerInfo::setLevel()
{
}

PlayerInfo::setWhetherBanned()
{
}

PlayerInfo::setReasonOfBanning()
{
}

String PlayerInfo::getID()
{
}

String PlayerInfo::getName()
{
}

String PlayerInfo::getSign()
{
}

Double PlayerInfo::getLevel()
{
}

Boolean PlayerInfo::WhetherBanned()
{
}

String PlayerInfo::getReasonOfBanning()
{
}

PlayerInfo::Player()()
{
}

PlayerInfo::~Player()()
{
}

PlayerInfo::showConfiguration()
{
}

PlayerInfo::showUpdateInfo()
{
}

PlayerInfo::showRequestQueryResult()
{
}

PlayerInfo::PlayerInfo()
{
}


