#include "Layer.h"

Layer::T_Layer()
{
}

void Layer::~T_Layer()
{
}

Layer::SetWidth()
{
}

Integer Layer::GetWidth()
{
}

Layer::SetHeight()
{
}

Integer Layer::GetHeight()
{
}

Layer::SetPosition()
{
}

Integer Layer::GetX()
{
}

Integer Layer::GetY()
{
}

Layer::SetVisible()
{
}

Boolean Layer::IsVisible()
{
}

Layer::SetLayerTypeID()
{
}

Integer Layer::GetLayerTypeID()
{
}

Layer::setZorder()
{
}

Integer Layer::getZorder()
{
}

Layer::Move()
{
}

String Layer::ClassName()
{
}

Layer::Draw()
{
}

Layer::Layer()
{
}


