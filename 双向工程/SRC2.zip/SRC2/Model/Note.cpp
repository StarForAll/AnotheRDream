#include "Note.h"

Note::setWidth()
{
}

Note::setHeight()
{
}

Note::setX()
{
}

Note::setY()
{
}

Note::setSpeed()
{
}

Note::setRatio()
{
}

Integer Note::getWidth()
{
}

Integer Note::getHeight()
{
}

Integer Note::getX()
{
}

Integer Note::getY()
{
}

Integer Note::getSpeed()
{
}

Double Note::getRatio()
{
}

Note::Note()
{
}

Note::~Note()
{
}

Note::checkScore()
{
}

