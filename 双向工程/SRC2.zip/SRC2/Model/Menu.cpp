#include "Menu.h"

Menu::T_Menu()
{
}

Menu::~T_Menu()
{
}

Menu::SetMenuBkg()
{
}

Menu::SetBtnBmp()
{
}

Menu::SetMenuInfo()
{
}

Menu::AddMenuItem()
{
}

Menu::DrawMenu()
{
}

Integer Menu::MenuTap()
{
}

Integer Menu::GetMenuIndex()
{
}

Menu::SetMenuIndex()
{
}

Menu::DestroyAll()
{
}

Menu::SetCTapSound()
{
}

Menu::ClickMenuKey()
{
}

Menu::UpdateConfiguration()
{
}

Menu::Menu()
{
}


Integer Menu::GetMenuIndex()
{
}

StringAlignment Menu::GetAlignment()
{
}

FontStyle Menu::GetFontStyle()
{
}

