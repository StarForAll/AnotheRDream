#include "Map.h"

Map::Map()
{
}

Map::~Map()
{
}

Map::SetUpdate()
{
}

Boolean Map::GetUpdate()
{
}

String Map::ClassName()
{
}

Map::SetTile()
{
}

Integer Map::GetTile()
{
}

Map::Redraw()
{
}

Map::Draw()
{
}

