#include "LAYER_TYPE.h"

LAYER_TYPE::LAYER_TYPE()
{
}


